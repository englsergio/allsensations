<?php
/**
 * Shipping Calculator
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( 'no' === get_option( 'woocommerce_enable_shipping_calc' ) || ! WC()->cart->needs_shipping() ) {
	return;
}

?>
 
<?php do_action( 'woocommerce_before_shipping_calculator' ); ?>
 
<form class="woocommerce-shipping-calculator" action="<?php echo esc_url( WC()->cart->get_cart_url() ); ?>" method="post">
 
	<p><a href="#" class="shipping-calculator-button"><?php _e( 'Calculate Shipping', 'woocommerce' ); ?></a></p>
 
	<section class="shipping-calculator-form" style="display: none;">
 
		<input type="hidden" name="calc_shipping_country" value="BR" />
		<input type="hidden" name="calc_shipping_state" value="SP" />
 
		<p class="form-row form-row-wide">
			<input type="text" class="input-text" value="<?php echo esc_attr( WC()->customer->get_shipping_postcode() ); ?>" placeholder="<?php _e( 'Postcode / Zip', 'woocommerce' ); ?>" name="calc_shipping_postcode" id="calc_shipping_postcode" />
		</p>
 
		<p><button type="submit" name="calc_shipping" value="1" class="button"><?php _e( 'Update Totals', 'woocommerce' ); ?></button></p>
 
		<?php wp_nonce_field( 'woocommerce-cart' ); ?>
	</section>
</form>
 
<?php do_action( 'woocommerce_after_shipping_calculator' ); ?>